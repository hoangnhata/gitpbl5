export { default as SearchResults } from "./Result";

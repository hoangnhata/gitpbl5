export {default as Hero} from "./Hero";
export {default as Images} from "./Images";
export {default as Details} from "./detail"